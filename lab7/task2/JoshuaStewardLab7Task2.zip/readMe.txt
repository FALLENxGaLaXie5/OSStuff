In the algorithm, I checked to see if the initial allocations put the system in a state where there aren't enough resources to grant the request. It's giving me an error when I run this.

I'm also not completely solid on how the banking algorithm works, and I think when I made copies to check the initial states I might have allocated memory incorrectly.
