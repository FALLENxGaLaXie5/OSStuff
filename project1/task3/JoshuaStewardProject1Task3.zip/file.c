/**
 * Joshua Steward
 * Project 1 Task 3
 * 11/3/2016
 **/

#include <math.h>
#include <stdlib.h>
#include <string.h>
//#include <fuse.h>
#include <errno.h>
#include <sys/stat.h>
#include <time.h>
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>

#define BLOCK_SIZE 256
#define MAX_NAME_LENGTH 128
#define DATA_SIZE 254
#define INDEX_SIZE 127


typedef char data_t;
typedef unsigned short index_t;

typedef enum
{
    DIR,
    FIL,
    INDEX,
    DATA
} NODE_TYPE;

typedef struct fs_node
{
    char name[MAX_NAME_LENGTH];
    //fd - the name is the directory name (path), and the size refers to the numberf of files
    time_t creat_t; // creation time
    time_t access_t; // last access
    time_t mod_t; // last modification
    mode_t access; // access rights for the file
    unsigned short owner; // owner ID
    unsigned short size;
    index_t block_ref; // reference to the data or index block - points to the node which is of type index node
    //within the index node are several file descriptor nodes which either refer to a file or subdirectory

} FS_NODE;


typedef struct node
{
    NODE_TYPE type;
    union
    {
        FS_NODE fd; //file descriptor - this means it is a directory node.
        //fd - the name is the directory name (path), and the size refers to the numberf of files
        //  in the directory
        data_t data[DATA_SIZE]; // unsigned chars representing file data
        index_t index[INDEX_SIZE]; //stores where all the blocks of data for a file are located
        //, since a file might span multiple blocks
    } content;
} NODE;

NODE *memory; // allocate 2^16 blocks (in init)
char *bitVector; //allocate space for managing 2^16 blocks (in init)

/**
 * Finds first free block of memory
 * @return index block index in bit vector
 */
int findFreeBlock()
{
    for (int i = 0; i < (int)powf(2.0, 16.0); ++i)
    {
        if (bitVector[i] == '0')
        {
            return i;
        }
    }
    return -1;
}


/**
 * Will create the file system - allocate and initialize all structures and auxiliary data; create the superblock
 *
 *
 */
void init()
{
    float numBlocks = powf(2.0,16.0);
    bitVector = (char*)malloc((int)numBlocks);
    for (int j = 0; j < (int)numBlocks; ++j)
    {
        bitVector[j] = '0';
    }

    memory = (NODE*)malloc((int)numBlocks * sizeof(BLOCK_SIZE));
    memory[0].type = DIR;
    strcpy(memory[0].content.fd.name,"/");
    memory[0].content.fd.size = 0;
    memory[0].content.fd.owner = 0;
    memory[0].content.fd.creat_t = 0;
    memory[0].content.fd.access = 0;
    bitVector[0] = '1';
    //TODO: acess - should not allow for deletion or name change
    //TODO: - how to initialize block size
    for(int i = 0; i < numBlocks; i++)
    {

    }
}

/**
 * Create a file - allocate on block for meta-level information; set the size to 0,
 * the times to the current time, and the access rights to some default
 *
 * create a fd node for that file filled with the correct default attributes.
 * Note that files will all be empty as of task3. Inserting data happens in task 4
 *
 * size in file descriptor refers to size of file in bytes
 * depending on the size the block reference refers to
 *
 * size <= 254 bytes - a data node containing all of the file's data
 * size > 254 bytes - an index node containing indexes to all data nodes for that file
 */
void createFile(char *name)
{
    NODE newFile;
    newFile.type = FIL;
    newFile.content.fd.size = 0;
    newFile.content.fd.creat_t = time(NULL);
    newFile.content.fd.access_t = time(NULL);
    newFile.content.fd.mod_t = time(NULL);
    strcpy(newFile.content.fd.name, name);
    //TODO: access rights set to some default

    //assign to memory slot
    int i;
    if (i = findFreeBlock())
    {
        memory[i] = newFile;
        bitVector[i] = '0';
    }
    else
    {
        printf("Out of memory!");
    }

}

/**
 * Just like creating a file, but with a different type
 */
void createDirectory()
{

}

/**
 * Delete a file, return blocks and clean up your supporting structures; e.g., reset the bits in the bit vector
 * - Get rid of all the data, index, and the file descriptor nodes for a file
 */
void deleteFile()
{

}

/**
 * Delete the files from the directory, and then delete the directory; clean up
 */
void deleteDirectory()
{

}

/**
 * Obtain file type - file or directory, size, times, access right, owner
 * Print out a fd_node's attributes
 */
void obtainFileInfo()
{

}


int main(int argc, char *argv[])
{
    init();
    //return fuse_main(argc, argv, &hello_oper, NULL);
}