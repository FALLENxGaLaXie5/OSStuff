ReadMe:


Task 1) Confident
Task 2) Got everything except for last file. It is generating a random string of random length but wouldn't let me assign to global variable. 

Task3) Confident everything works 
Task4) I didn't get a chance to test extensively, but it opens/closes/writes from the tests I did.

Task5) Fuze... broke my code over and over...

Task6) I believe since I took a parent index in to create files and directories and then used the index nodes to keep track of this, it is a hierarchal structure. So, I did this in task3/4.


I'm submitting tasks 3,4, and 6 as the same zip, since they are essentially all built on eachother. Thanks for all the help!
