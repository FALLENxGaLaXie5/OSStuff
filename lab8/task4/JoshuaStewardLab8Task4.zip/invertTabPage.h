/*
 * Joshua Steward
 * 10/25/16
 * Lab 8 Task 4
 *
 */

struct invTablePage
{
	int pid;
    int pageIndex;
    int timeStamp;
	int pageNum;
	int memorySize, frameSize;
	int physicalAdd;
}invTablePage;
