ReadMe



Was having issues when creating dynamic library. In task 2, he initialized it with a pointer to the library function, but I couldn't find anything on using pointers to the functions with parameters passed, so it's still giving some errors on compilation.


