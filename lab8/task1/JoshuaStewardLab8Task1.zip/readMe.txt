Joshua Steward
10/20/2016
Lab 8 Task1


When built without a static library, the program runs. With a static library built,
    i.e. all library functions are linked to the program, it runs the same.