/*
 *  giveMeNum.c
 *  lect09
 *
 *  Created by AJ Bieszczad on 3/16/09.
 *  Copyright 2009 CSUCI. All rights reserved.
 *
 */

#include <stdio.h>
#include <stdlib.h>

int giveMeNum ()
{
   int n;
   printf("Give me a number: \n");
   scanf("%d", &n);
   return n;
}

